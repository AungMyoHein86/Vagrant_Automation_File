#!/bin/bash
##############################
### Author: Ethan Zaw
### Created date: 23/06/2023
### Modified date: 28/06/2023
### Version: 1.1
##############################

echo "[Task 1] Initialize..........."
HOMEDIR=$HOME/module-2
OLDHOMEDIR=$HOME/kube-demo
Template=template-cli-box
FirstItem=Vagrantfile
SecondItem=scripts
ThirdItem=.ssh
FourthItem=manifests

# Prepare the template folder
cd $HOMEDIR/
tar -xvpf template-cli-box.tar
sleep 2 
echo

echo "[Task 2] Creatre New Directory..........." 
read -p "New folder name, Example: <name-cli-box>: " foldername
mkdir -p $HOMEDIR/$foldername
sleep 2
echo

echo "[Task 3] Preparing Working Directory..........."
cp -p $HOMEDIR/$Template/$FirstItem $HOMEDIR/$foldername/
cp -rp $HOMEDIR/$Template/$SecondItem $HOMEDIR/$foldername/
cp -rp $HOMEDIR/$Template/$ThirdItem $HOMEDIR/$foldername/
cp -rp $HOMEDIR/$Template/$FourthItem $HOMEDIR/$foldername/
sleep 2
echo

echo "[Task 4] Assign IP Address for new vagrantbox..........."
echo "Below IPs are in used:"
cat $HOMEDIR/*/Vagrantfile | grep vm1.vm.network | grep -v 192.168.56.0 | awk '{print $4}' | tr -d '"|,' | sort -u
cat $OLDHOMEDIR/*/Vagrantfile | grep vm1.vm.network | grep -v 192.168.56.0 | awk '{print $4}' | tr -d '"|,' | sort -u
read -p "Choose available IP from 192.168.56.2-253: " ipAddress
sleep 1
# cd $HOMEDIR/$foldername/
# Replace IP
sed -i'' -e "s/192.168.56.0/$ipAddress/g" $HOMEDIR/$foldername/Vagrantfile
rm -f Vagrantfile-e
sleep 1
echo

echo "[Task 5] Preparing Vagrant file..........."
cd $HOMEDIR/$foldername/
# Replace foldername
sed -i'' -e "s/template-cli-box/$foldername/g" Vagrantfile
rm -f Vagrantfile-e
sleep 2
echo
echo "############################## DONE ##############################"
sleep 2
echo Folder name $foldername is created under home directory of $HOMEDIR

# Cleaning up template folder
cd $HOMEDIR
rm -rf template-cli-box
echo
sleep 2
